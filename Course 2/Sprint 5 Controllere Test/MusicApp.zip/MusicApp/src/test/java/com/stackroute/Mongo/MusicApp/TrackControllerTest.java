package com.stackroute.Mongo.MusicApp;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.Mongo.MusicApp.controller.TrackController;
import com.stackroute.Mongo.MusicApp.exception.TrackAlreadyExistException;
import com.stackroute.Mongo.MusicApp.exception.TrackNotFoundException;
import com.stackroute.Mongo.MusicApp.model.Artist;
import com.stackroute.Mongo.MusicApp.model.Track;
import com.stackroute.Mongo.MusicApp.repository.TrackRepository;
import com.stackroute.Mongo.MusicApp.service.TrackService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class TrackControllerTest {
    @Autowired
    private MockMvc mockMvc;
    @Mock
    private TrackService trackService;
    @InjectMocks
    private TrackController trackController;
    private Track track,track1;
    private Artist artist;
    @BeforeEach
    public void setup(){
        artist=new Artist("AR1","Justin");
        track=new Track("TR001","Sorry","4.5",artist);
        track1=new Track("TR002","I Feel Good","5",
                new Artist("AR2","XYZ"));
        mockMvc= MockMvcBuilders.standaloneSetup(trackController).build();
    }
    @AfterEach
    public void clean(){
        track=null; track1=null; artist=null;
    }

    //method for converting the java object to json object
    public static String convertToJson(final Object object){
        String result="";
        ObjectMapper mapper=new ObjectMapper();
        try {
            result=mapper.writeValueAsString(object);
        }catch (JsonProcessingException je){
            throw new RuntimeException(je);
        }
        return result;
    }

    @Test //success test for addTrack()
    public void testAddTrackSuccess()throws Exception{
        when(trackService.addTrack(track)).thenReturn(track);
        //need to create post type of req using MockMvc Object
        // and attached data as json format
        mockMvc.perform(
                        post("/addTrack")
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(convertToJson(track)))// raises req,,controller methods get invoked
                //above code execute the controller addBook() method and call service addBook()
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());//give the response and print it
        verify(trackService,times(1)).addTrack(track);
    }

    @Test //failure test case for addTrack()
    public void testAddTrackFailure() throws Exception {
        when(trackService.addTrack(track)).thenThrow(TrackAlreadyExistException.class);
        mockMvc.perform(
                post("/addTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(track)))
                .andExpect(status().isConflict()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).addTrack(track);
    }

    @Test //test for gelAllTracks() method
    public void testGetAllTrack() throws Exception {
        when(trackService.getAllTracks()).thenReturn(List.of(track,track1));
        mockMvc.perform(
                get("/getTrack"))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).getAllTracks();
    }

    @Test //success test case for deleteTrack()
    public void testDeleteTrackSuccess() throws Exception {
        when(trackService.deleteTrack("TR001")).thenReturn(true);
        mockMvc.perform(
                delete("/delete-track-by-id/TR001"))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).deleteTrack("TR001");
    }

    @Test //failure test case for deleteTrack()
    public void testDeleteTrackFailure() throws Exception {
        when(trackService.deleteTrack("TR003")).thenThrow(TrackNotFoundException.class);
        mockMvc.perform(
                delete("/delete-track-by-id/TR003"))
                .andExpect(status().isNotFound()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).deleteTrack("TR003");
    }

    @Test //success test case for updateTrack()
    public void testUpdateTrackSuccess() throws Exception {
        when(trackService.updateTrack(track)).thenReturn(track);
        mockMvc.perform(
                put("/updateTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(track)))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).updateTrack(track);
    }

    @Test //failure test for updateTrack()
    public void testUpdateTrackFailure() throws Exception {
        when(trackService.updateTrack(track)).thenThrow(TrackNotFoundException.class);
        mockMvc.perform(
                put("/updateTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(track)))
                .andExpect(status().isNotFound()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).updateTrack(track);
    }

    @Test //test for getTrackByArtist()
    public void testGetTrackByArtist() throws Exception {
        when(trackService.getTrackByArtist("Justin")).thenReturn(List.of(track,track1));
        mockMvc.perform(
                get("/get-track-by-artist/Justin"))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
        verify(trackService,times(1)).getTrackByArtist("Justin");
    }

}
