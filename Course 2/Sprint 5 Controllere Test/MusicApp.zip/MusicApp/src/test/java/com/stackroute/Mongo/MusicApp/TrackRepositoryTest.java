package com.stackroute.Mongo.MusicApp;

import com.stackroute.Mongo.MusicApp.model.Artist;
import com.stackroute.Mongo.MusicApp.model.Track;
import com.stackroute.Mongo.MusicApp.repository.TrackRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(SpringExtension.class)
@DataMongoTest
public class TrackRepositoryTest {
    @Autowired
    private TrackRepository trackRepository;
    private Track track;
    private Artist artist;
    @BeforeEach
    public void setup(){
        track=new Track("TR001","XYZ","5.5",
                new Artist("AR1","ABC"));

    }
    @AfterEach
    public void clean(){
        track=null;
        artist=null;
        trackRepository.deleteAll();
    }

    @Test //test case for findAll()
    public void testFindAll(){
        trackRepository.save(track);
        Track track1=new Track("TR002","PQR","5",artist);
        trackRepository.save(track1);
        assertIterableEquals(Arrays.asList(track,track1),trackRepository.findAll());
    }

    @Test //success test case for insert
    public void testInsertSuccess(){
        trackRepository.insert(track);
        Track result=trackRepository.findById(track.getTrackId()).get();
        System.out.println(track.equals(result));
        assertEquals(true,track.equals(result));
    }

    @Test //failure test for insert
    public void  testInsertFailure(){
        trackRepository.insert(track); //inserting record
        assertThrows(DuplicateKeyException.class,()->trackRepository.insert(track));
        //if we try to insert duplicate id then insert()method throws the exception
    }

    @Test //test for deleteById() method
    public void testDeleteById(){
        //first insert the book record
        trackRepository.insert(track);
        //then try to delete the record
        trackRepository.deleteById(track.getTrackId());
        assertEquals(true,trackRepository.findById(track.getTrackId()).isEmpty());
        //get the book id
    }

    @Test
    //test case for update method
    public void testUpdateMethod(){

        trackRepository.insert(track);
        Track result=trackRepository.findById(track.getTrackId()).get();
        track.setTrackName("sdjkhd");
        trackRepository.save(track);
        assertEquals(track,trackRepository.findById("TR001").get());

    }


}
